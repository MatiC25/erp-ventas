package com.iconnect.erp_ventas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
